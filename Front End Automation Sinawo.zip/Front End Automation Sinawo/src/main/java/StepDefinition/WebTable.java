package StepDefinition;

import Pages.LandingPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


import cucumber.api.java.en.When;

public class  WebTable extends CommonSteps{



    @Given("^I am on the home page$")
    public void i_am_on_the_home_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        i_Open_link_in_Browser();

    }

    @When("^I look for my \"([^\"]*)\"$")
    public void i_look_for_my(String name)  {
        // Write code here that turns the phrase above into concrete actions
        WebElement searchButton = wdriver.findElement(By.xpath(LandingPage.landingpageSearchBox));
        searchButton.sendKeys(name);
    }

    @Then("^my \"([^\"]*)\"> must be displayed on the table$")
    public void my_must_be_displayed_on_the_table(String name)  {
        // Write code here that turns the phrase above into concrete actions
        WebElement landingPageTable = wdriver.findElement(By.xpath(LandingPage.landingpageTable));
        if (landingPageTable.isEnabled())
        {
            System.out.println("Success");
        }

    }

    @Given("^i want to add a user$")
    public void i_want_to_add_a_user() {
        // Write code here that turns the phrase above into concrete actions
        WebElement searchButton = wdriver.findElement(By.xpath(LandingPage.landingpageAddUser));
        searchButton.click();
    }

    @When("^i enter \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
    public void i_enter_and(String FirstName, String LastName, String Username,
                            String Password, String Customer, String Role, String Email, String Cellphone)  {
        // Write code here that turns the phrase above into concrete actions

        WebElement firstname = wdriver.findElement(By.xpath(LandingPage.addUserFirstName));
        WebElement lastname = wdriver.findElement(By.xpath(LandingPage.addUserLastName));
        WebElement username = wdriver.findElement(By.xpath(LandingPage.addUserUserName));
        WebElement password = wdriver.findElement(By.xpath(LandingPage.addUserPassword));
        WebElement customer = wdriver.findElement(By.xpath(LandingPage.addUserCustomer));
        WebElement role = wdriver.findElement(By.xpath(LandingPage.addUserRole));
        WebElement email = wdriver.findElement(By.xpath(LandingPage.addUserEmail));
        WebElement cellphone = wdriver.findElement(By.xpath(LandingPage.addUserCellphone));

        firstname.sendKeys(FirstName);
        username.sendKeys(Username);
        password.sendKeys(Password);
        role.sendKeys(Role);
        lastname.sendKeys(LastName);
        customer.click();
        email.sendKeys(Email);
        cellphone.sendKeys(Cellphone);
    }

    @Then("^my details must be added$")
    public void my_details_must_be_added()  {
        // Write code here that turns the phrase above into concrete actions

        WebElement btnSave = wdriver.findElement(By.xpath(LandingPage.addSaveButton));
        btnSave.click();
    }

}
