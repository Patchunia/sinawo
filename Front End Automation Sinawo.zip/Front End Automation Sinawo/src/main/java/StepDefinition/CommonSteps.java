package StepDefinition;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;



import Library.WebDriverUtilities;


public abstract class CommonSteps
{

	public static WebDriver wdriver;
	public static String strCapAppPackage = "";
	public static String strCapPlatformName = "";
	public static String strBuildBatFilePath = "";
	public static String Browser = "";
	static Properties prop = new Properties();
	public ExtentReports rep = Library.ExtentManager.getInstance();
	public ExtentTest test;

	
	
	/**
	 * Description: Constructor for CommonSteps
	 * Creates properties file object for use in the class
	 */
	public CommonSteps()
	{
		InputStream input = null;

		try
		{
			input = new FileInputStream("global.properties");

			// load a properties file
			prop.load(input);

		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	
	/**
	 * Description: Common step for I_Open_Web_MFC_Application_In_Browser step definition steps
	 * @throws Throwable
	 */
	
	public void i_Open_link_in_Browser() throws Throwable, MalformedURLException
	{
		String strCapAppPathName="";
		//String chromeDriverPath="C:\\Users\\f5182093\\Documents\\Front End Automation\\Libs\\BrowserDrivers";

		Browser = prop.getProperty("browser.name");
		System.out.println();
		strCapAppPathName = prop.getProperty("cap.App");
		//chromeDriverPath = prop.getProperty("cap.chromePath");
		System.out.println(" Starting test - Opening browser");

		Thread.sleep(1000);


			System.out.println(" Chrome browser opened");
			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			System.setProperty("webdriver.chrome.driver", "./Libs/BrowserDrivers/chromedriver.exe");
			wdriver = new ChromeDriver(cap);	
			WebDriverUtilities util = new WebDriverUtilities(wdriver);
			wdriver.get(strCapAppPathName);			
			Thread.sleep(3000);
			wdriver.manage().window().maximize();
			Thread.sleep(5000);


		

		
	}




}
