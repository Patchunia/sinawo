package Library;


import org.openqa.selenium.WebDriver;


public class WebDriverUtilities
{
	WebDriver driver;
	public String time;
	public WebDriverUtilities(WebDriver driver)
	{
		this.driver = driver;
	}
	//=================================================================================================================================================
	public static void driverquit(WebDriver driver)
	{
		driver.quit();
	}



}

