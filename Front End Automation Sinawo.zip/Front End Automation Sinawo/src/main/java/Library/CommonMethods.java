package Library;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class CommonMethods
{
	
	public static String strBuildBatFilePath="";

	public CommonMethods()
	{

		Properties prop = new Properties();
		InputStream input = null;

		try
		{
			input = new FileInputStream("global.properties");

			// load a properties file
			prop.load(input);

			//Retrieve the bat build file path from the properties file
			strBuildBatFilePath = prop.getProperty("npm.BuildFetchBatchFilePath");	    
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	

	//*****************************object synchronization***************************************************
	/**
	 * Description: 
	 * @param driver
	 * @param byType
	 * @param byString
	 * @param time
	 * @return
	 */
	public static WebElement isElementPresnt(WebDriver driver,String byType,String byString,int time)
	{

		WebElement ele = null;

		for(int i=0;i<time;i++)
		{
			try
			{
				if (byType.equals("id"))
				{
					ele=driver.findElement(By.id(byString));
					break;
				}
				else
				{
					ele=driver.findElement(By.xpath(byString));
					break;
				}
			}
			catch(Exception e)
			{
				try 
				{
					Thread.sleep(80);
				} catch (InterruptedException e1) 
				{
					System.out.println("Waiting for element to appear");
				}
			}
		}
		return ele;
	}

	

	//************************************************ Object Synchronization*********************************************************************************************************

	/**
	 * 
	 * @param driver
	 * @param id
	 * @param time
	 * @return
	 */
	public static WebElement isElementPresent(WebDriver driver, String id, int time)
	{
		WebElement ele = null;
		for (int i =0;i<time;i++)
		{
			try
			{
				ele=driver.findElement(By.id(id));
				break;
			}
			catch (Exception e)
			{
				try
				{
					Thread.sleep(400);
				}
				catch (InterruptedException e1)
				{

					System.out.println("Waiting for element to appear");
				}
			}
		}
		return ele;

	}

}
