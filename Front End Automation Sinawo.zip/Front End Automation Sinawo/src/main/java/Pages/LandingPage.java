package Pages;

public class LandingPage {
	
	public static String landingpageSearchBox="/html/body/table/thead/tr[1]/td/input";
	public static String landingpageTable="/html/body/table/tbody/tr[contains(text(),'')]";
	public static String landingpageAddUser = "/html/body/table/thead/tr[2]/td/button";
	public static String addUserFirstName = "/html/body/div[3]/div[2]/form/table/tbody/tr[1]/td[2]/input";
	public static String addUserLastName = "/html/body/div[3]/div[2]/form/table/tbody/tr[2]/td[2]/input";
	public static String addUserUserName= "/html/body/div[3]/div[2]/form/table/tbody/tr[3]/td[2]/input";
	public static String addUserCustomer = "/html/body/div[3]/div[2]/form/table/tbody/tr[5]/td/label/input[contains((text),\"\")]";
	public static String addUserPassword= "/html/body/div[3]/div[2]/form/table/tbody/tr[4]/td[2]/input";
	public static String addUserRole = "/html/body/div[3]/div[2]/form/table/tbody/tr[6]/td[2]/select";
	public static String addUserEmail = "/html/body/div[3]/div[2]/form/table/tbody/tr[7]/td[2]/input";
	public static String addUserCellphone = "/html/body/div[3]/div[2]/form/table/tbody/tr[8]/td[2]/input";
	public static String addSaveButton = "/html/body/div[3]/div[3]/button[2]";
}
