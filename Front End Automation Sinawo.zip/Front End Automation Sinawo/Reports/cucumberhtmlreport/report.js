$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("GD-1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.feature");
formatter.feature({
  "line": 1,
  "name": "Login using NedID",
  "description": "",
  "id": "login-using-nedid",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "NEDIDLogin",
  "description": "",
  "id": "login-using-nedid;nedidlogin",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@NedIDLogin"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User accesses Ned app and landing pg displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User clicks on get started button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "User captures NedbankID \"\u003cNedID\u003e\" and password \"\u003cPassword\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User clicks Login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "User waits for login approval",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Dashboard page should display",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Logoff",
  "keyword": "And "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "login-using-nedid;nedidlogin;",
  "rows": [
    {
      "cells": [
        "NedID",
        "Password"
      ],
      "line": 14,
      "id": "login-using-nedid;nedidlogin;;1"
    },
    {
      "cells": [
        "Testing1",
        "Testing1"
      ],
      "line": 15,
      "id": "login-using-nedid;nedidlogin;;2"
    },
    {
      "cells": [
        "Testing2",
        "Testing"
      ],
      "line": 16,
      "id": "login-using-nedid;nedidlogin;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "NEDIDLogin",
  "description": "",
  "id": "login-using-nedid;nedidlogin;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@NedIDLogin"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User accesses Ned app and landing pg displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User clicks on get started button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "User captures NedbankID \"Testing1\" and password \"Testing1\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User clicks Login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "User waits for login approval",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Dashboard page should display",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Logoff",
  "keyword": "And "
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.user_accesses_Ned_app_and_landing_pg_displayed()"
});
formatter.result({
  "duration": 40683829543,
  "status": "passed"
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.user_clicks_on_get_started_button()"
});
formatter.result({
  "duration": 1321076109,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Testing1",
      "offset": 25
    },
    {
      "val": "Testing1",
      "offset": 49
    }
  ],
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.user_captures_NedbankID_and_password(String,String)"
});
formatter.result({
  "duration": 10483395705,
  "status": "passed"
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.User_clicks_Login_button()"
});
formatter.result({
  "duration": 671468893,
  "status": "passed"
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.user_waits_for_login_approval()"
});
formatter.result({
  "duration": 7611584557,
  "status": "passed"
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.dashboard_page_should_display()"
});
formatter.result({
  "duration": 22270056056,
  "status": "passed"
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.Logoff()"
});
formatter.result({
  "duration": 2594906048,
  "status": "passed"
});
formatter.after({
  "duration": 164219,
  "status": "passed"
});
formatter.after({
  "duration": 26844,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "NEDIDLogin",
  "description": "",
  "id": "login-using-nedid;nedidlogin;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 3,
      "name": "@NedIDLogin"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User accesses Ned app and landing pg displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User clicks on get started button",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "User captures NedbankID \"Testing2\" and password \"Testing\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User clicks Login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "User waits for login approval",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Dashboard page should display",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Logoff",
  "keyword": "And "
});
formatter.match({
  "location": "GD1638_Login_by_Nedbank_ID_and_Password_with_bank_product_linked.user_accesses_Ned_app_and_landing_pg_displayed()"
});
